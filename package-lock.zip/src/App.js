import "./App.css";
import Pathroutes from "./Pathroutes";
function App() {
  return (
    <div className="App">
      <Pathroutes />
    </div>
  );
}

export default App;
